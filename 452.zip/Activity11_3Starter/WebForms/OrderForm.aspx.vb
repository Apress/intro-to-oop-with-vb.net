Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents ddlProductCategories As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dgProducts As System.Web.UI.WebControls.DataGrid
    Protected WithEvents dgOrderItems As System.Web.UI.WebControls.DataGrid
    Private dsProducts As DataSet
    Protected WithEvents btnPlaceOrder As System.Web.UI.WebControls.Button
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Private oOrder As Order
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            Dim oProductCatalog As New ProductCatalog()
            dsProducts = oProductCatalog.getProductInfo
            Session("dsProducts") = dsProducts
            BindList()
            BindProductsGrid()
        Else
            dsProducts = CType(Session("dsProducts"), DataSet)
        End If

    End Sub
    Private Sub BindList()
        ddlProductCategories.DataSource = dsProducts
        ddlProductCategories.DataMember = "Category"
        ddlProductCategories.DataValueField = "CatID"
        ddlProductCategories.DataTextField = "Name"
        ddlProductCategories.DataBind()
    End Sub
    Private Sub BindProductsGrid()
        Dim dv As New DataView(dsProducts.Tables("Product"))
        dv.RowFilter = "CatID = " & _
            ddlProductCategories.Items.Item _
            (ddlProductCategories.SelectedIndex).Value
        dgProducts.DataSource = dv
        dgProducts.DataBind()
    End Sub

    Private Sub ddlProductCategories_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProductCategories.SelectedIndexChanged
        BindProductsGrid()
    End Sub

    Private Sub dgProducts_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgProducts.ItemCommand

        If IsNothing(Session("EmployeeID")) Then
            Response.Redirect("Login.aspx")
        End If

        If Not IsNothing(Session("Order")) Then
            oOrder = CType(Session("Order"), Order)
        Else
            oOrder = New Order()
        End If

        Dim ProductIDCell As TableCell = e.Item.Cells(1)
        Dim UnitPriceCell As TableCell = e.Item.Cells(4)
        Dim ProductID As String = ProductIDCell.Text
        Dim UnitPrice As String = UnitPriceCell.Text

        oOrder.AddItem(New OrderItem(ProductID, CDbl(UnitPrice), 1))
        BindOrderGrid()
        
    End Sub
    Private Sub BindOrderGrid()
        dgOrderItems.DataSource = oOrder.OrderItems
        dgOrderItems.DataBind()
        Session("Order") = oOrder
        If oOrder.OrderItems.Count > 0 Then
            btnPlaceOrder.Enabled = True
        Else
            btnPlaceOrder.Enabled = False
        End If
    End Sub

    Private Sub dgOrderItems_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgOrderItems.DeleteCommand
        oOrder = CType(Session("Order"), Order)
        Dim ProductIDCell As TableCell = e.Item.Cells(0)
        Dim ProductID As String = ProductIDCell.Text
        oOrder.RemoveItem(ProductID)
        BindOrderGrid()
    End Sub

    Private Sub btnPlaceOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaceOrder.Click
        oOrder = CType(Session("Order"), Order)
        If oOrder.OrderItems.Count > 0 Then
            lblMessage.Text = oOrder.PlaceOrder(Session("EmployeeID")).ToString
        Else
            lblMessage.Text = "There are no items in the order."
        End If
    End Sub
End Class
