'/// Persists order data to the databas.
'/// Uses the up_PlaceOrder stored procedure
Imports System.Data.SqlClient
Public Class dbOrder
    Public Function PlaceOrder(ByVal xmlOrder As String) As Integer
        Dim cn As SqlConnection = New SqlConnection()
        cn.ConnectionString = "Integrated Security=True;Data Source=localhost;Initial Catalog=OfficeSupply"
        Try
            Dim cmd As SqlCommand = cn.CreateCommand()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "up_PlaceOrder"

            Dim inParameter As New SqlParameter()
            inParameter.ParameterName = "@xmlOrder"
            inParameter.Value = xmlOrder
            inParameter.DbType = DbType.String
            inParameter.Direction = ParameterDirection.Input
            cmd.Parameters.Add(inParameter)

            Dim ReturnParameter As New SqlParameter()
            ReturnParameter.ParameterName = "@OrderID"
            ReturnParameter.Direction = ParameterDirection.ReturnValue
            cmd.Parameters.Add(ReturnParameter)

            Dim intOrderNo As Integer
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            intOrderNo = cmd.Parameters("@OrderID").Value
        Return intOrderNo
        Catch ex As Exception
            'Debug.WriteLine(ex.ToString)
        End Try
    End Function
End Class
