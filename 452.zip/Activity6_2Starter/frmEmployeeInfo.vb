Public Class frmEmployeeInfo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblEmpID As System.Windows.Forms.Label
    Friend WithEvents btnExistingEmp As System.Windows.Forms.Button
    Friend WithEvents btnNewEmp As System.Windows.Forms.Button
    Friend WithEvents gbSecurityInfo As System.Windows.Forms.GroupBox
    Friend WithEvents btnUpdateSI As System.Windows.Forms.Button
    Friend WithEvents txtLoginName As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblLoginName As System.Windows.Forms.Label
    Friend WithEvents txtEmpID As System.Windows.Forms.TextBox
    Friend WithEvents gbHRInfo As System.Windows.Forms.GroupBox
    Friend WithEvents btnUpdateHR As System.Windows.Forms.Button
    Friend WithEvents txtSSN As System.Windows.Forms.TextBox
    Friend WithEvents lblDepartment As System.Windows.Forms.Label
    Friend WithEvents txtDepartment As System.Windows.Forms.TextBox
    Friend WithEvents lblSSN As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button



    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.gbSecurityInfo = New System.Windows.Forms.GroupBox()
        Me.btnUpdateSI = New System.Windows.Forms.Button()
        Me.txtLoginName = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblLoginName = New System.Windows.Forms.Label()
        Me.txtDepartment = New System.Windows.Forms.TextBox()
        Me.lblSSN = New System.Windows.Forms.Label()
        Me.btnUpdateHR = New System.Windows.Forms.Button()
        Me.txtEmpID = New System.Windows.Forms.TextBox()
        Me.btnNewEmp = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtSSN = New System.Windows.Forms.TextBox()
        Me.lblEmpID = New System.Windows.Forms.Label()
        Me.btnExistingEmp = New System.Windows.Forms.Button()
        Me.gbHRInfo = New System.Windows.Forms.GroupBox()
        Me.lblDepartment = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.gbSecurityInfo.SuspendLayout()
        Me.gbHRInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbSecurityInfo
        '
        Me.gbSecurityInfo.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnUpdateSI, Me.txtLoginName, Me.lblPassword, Me.txtPassword, Me.lblLoginName})
        Me.gbSecurityInfo.Location = New System.Drawing.Point(16, 88)
        Me.gbSecurityInfo.Name = "gbSecurityInfo"
        Me.gbSecurityInfo.Size = New System.Drawing.Size(384, 80)
        Me.gbSecurityInfo.TabIndex = 12
        Me.gbSecurityInfo.TabStop = False
        Me.gbSecurityInfo.Text = "SecurityInfo"
        '
        'btnUpdateSI
        '
        Me.btnUpdateSI.Location = New System.Drawing.Point(280, 32)
        Me.btnUpdateSI.Name = "btnUpdateSI"
        Me.btnUpdateSI.Size = New System.Drawing.Size(88, 24)
        Me.btnUpdateSI.TabIndex = 5
        Me.btnUpdateSI.Text = "Update"
        '
        'txtLoginName
        '
        Me.txtLoginName.Location = New System.Drawing.Point(80, 18)
        Me.txtLoginName.Name = "txtLoginName"
        Me.txtLoginName.Size = New System.Drawing.Size(168, 20)
        Me.txtLoginName.TabIndex = 0
        Me.txtLoginName.Text = ""
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(19, 53)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(57, 13)
        Me.lblPassword.TabIndex = 4
        Me.lblPassword.Text = "Password:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(80, 50)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(168, 20)
        Me.txtPassword.TabIndex = 1
        Me.txtPassword.Text = ""
        '
        'lblLoginName
        '
        Me.lblLoginName.AutoSize = True
        Me.lblLoginName.Location = New System.Drawing.Point(8, 18)
        Me.lblLoginName.Name = "lblLoginName"
        Me.lblLoginName.Size = New System.Drawing.Size(68, 13)
        Me.lblLoginName.TabIndex = 2
        Me.lblLoginName.Text = "Login Name:"
        '
        'txtDepartment
        '
        Me.txtDepartment.Location = New System.Drawing.Point(80, 50)
        Me.txtDepartment.Name = "txtDepartment"
        Me.txtDepartment.Size = New System.Drawing.Size(168, 20)
        Me.txtDepartment.TabIndex = 1
        Me.txtDepartment.Text = ""
        '
        'lblSSN
        '
        Me.lblSSN.AutoSize = True
        Me.lblSSN.Location = New System.Drawing.Point(35, 19)
        Me.lblSSN.Name = "lblSSN"
        Me.lblSSN.Size = New System.Drawing.Size(31, 13)
        Me.lblSSN.TabIndex = 2
        Me.lblSSN.Text = "SSN:"
        '
        'btnUpdateHR
        '
        Me.btnUpdateHR.Location = New System.Drawing.Point(280, 32)
        Me.btnUpdateHR.Name = "btnUpdateHR"
        Me.btnUpdateHR.Size = New System.Drawing.Size(88, 24)
        Me.btnUpdateHR.TabIndex = 5
        Me.btnUpdateHR.Text = "Update"
        '
        'txtEmpID
        '
        Me.txtEmpID.Location = New System.Drawing.Point(88, 24)
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.Size = New System.Drawing.Size(168, 20)
        Me.txtEmpID.TabIndex = 10
        Me.txtEmpID.Text = ""
        '
        'btnNewEmp
        '
        Me.btnNewEmp.Location = New System.Drawing.Point(56, 56)
        Me.btnNewEmp.Name = "btnNewEmp"
        Me.btnNewEmp.Size = New System.Drawing.Size(96, 23)
        Me.btnNewEmp.TabIndex = 6
        Me.btnNewEmp.Text = "New Employee"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(304, 8)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(80, 23)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "Close"
        '
        'txtSSN
        '
        Me.txtSSN.Location = New System.Drawing.Point(80, 18)
        Me.txtSSN.Name = "txtSSN"
        Me.txtSSN.Size = New System.Drawing.Size(168, 20)
        Me.txtSSN.TabIndex = 0
        Me.txtSSN.Text = ""
        '
        'lblEmpID
        '
        Me.lblEmpID.Location = New System.Drawing.Point(8, 24)
        Me.lblEmpID.Name = "lblEmpID"
        Me.lblEmpID.Size = New System.Drawing.Size(72, 16)
        Me.lblEmpID.TabIndex = 9
        Me.lblEmpID.Text = "Employee ID:"
        '
        'btnExistingEmp
        '
        Me.btnExistingEmp.Location = New System.Drawing.Point(168, 56)
        Me.btnExistingEmp.Name = "btnExistingEmp"
        Me.btnExistingEmp.Size = New System.Drawing.Size(112, 23)
        Me.btnExistingEmp.TabIndex = 13
        Me.btnExistingEmp.Text = "Existing Employee"
        '
        'gbHRInfo
        '
        Me.gbHRInfo.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnUpdateHR, Me.txtSSN, Me.lblDepartment, Me.txtDepartment, Me.lblSSN})
        Me.gbHRInfo.Location = New System.Drawing.Point(18, 182)
        Me.gbHRInfo.Name = "gbHRInfo"
        Me.gbHRInfo.Size = New System.Drawing.Size(384, 80)
        Me.gbHRInfo.TabIndex = 12
        Me.gbHRInfo.TabStop = False
        Me.gbHRInfo.Text = "HRInfo"
        '
        'lblDepartment
        '
        Me.lblDepartment.AutoSize = True
        Me.lblDepartment.Location = New System.Drawing.Point(9, 53)
        Me.lblDepartment.Name = "lblDepartment"
        Me.lblDepartment.Size = New System.Drawing.Size(66, 13)
        Me.lblDepartment.TabIndex = 4
        Me.lblDepartment.Text = "Department:"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(400, 8)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(72, 24)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset"
        '
        'frmEmployeeInfo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(512, 357)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnReset, Me.gbHRInfo, Me.btnClose, Me.lblEmpID, Me.btnExistingEmp, Me.btnNewEmp, Me.gbSecurityInfo, Me.txtEmpID})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEmployeeInfo"
        Me.Text = "Employee Info"
        Me.gbSecurityInfo.ResumeLayout(False)
        Me.gbHRInfo.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnNewEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewEmp.Click


        
    End Sub

    Private Sub btnExistingEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExistingEmp.Click
        Try

            
        Catch eException As Exception
            MsgBox(eException.Message)
        End Try
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        txtEmpID.Text = ""
        txtEmpID.Enabled = True
        txtLoginName.Text = ""
        txtPassword.Text = ""
        txtSSN.Text = ""
        txtDepartment.Text = ""
    End Sub

    Private Sub btnUpdateSI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateSI.Click

    End Sub

    Private Sub btnUpdateHR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateHR.Click

    End Sub
End Class
