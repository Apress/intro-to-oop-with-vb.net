Public Class Employee
    Private intEmpID As Integer
    Private strLoginName As String
    Private strPassWord As String
    Private intSSN As Integer
    Private strDepartment As String

    Public ReadOnly Property EmployeeID() As Integer
        Get
            Return intEmpID
        End Get
    End Property
    Public Property LoginName() As String
        Get
            Return strLoginName
        End Get
        Set(ByVal Value As String)
            strLoginName = Value
        End Set
    End Property
    Public Property Password() As String
        Get
            Return strPassWord
        End Get
        Set(ByVal Value As String)
            strPassWord = Value
        End Set
    End Property
    Public Property SSN() As Integer
        Get
            Return intSSN
        End Get
        Set(ByVal Value As Integer)
            intSSN = Value
        End Set
    End Property
    Public Property Department() As String
        Get
            Return strDepartment
        End Get
        Set(ByVal Value As String)
            strDepartment = Value
        End Set
    End Property



    Public Sub New()


    End Sub


End Class
