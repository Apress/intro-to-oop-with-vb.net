These files are required to complete the activities contained 
in "An Introduction to Object-Oriented Programming with Visual Basic .NET".

In order to complete these activities Visual Studio .NET must be installed on your machine.

In addition, in order to complete the activities for Chapter 11, IIS 5.0 must be installed
with Frontpage server extensions enabled.

The Source code for the sample OSO Application is included in the OSODataBase, OSOBusTier
and the OSOGUIForms directories. This application requires that SQLServer 2000 is installed
using Windows Authentication and you are logged in as a user with rights to create the 
OSO Database. If you are using SQL Server authentication the connection strings
will need to be altered in the code.