Public Class dlgOrderItem
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtProductID As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
    Friend WithEvents nupQuantity As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ctnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtProductID = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.nupQuantity = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ctnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        CType(Me.nupQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ProductID:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Unit Price:"
        '
        'txtProductID
        '
        Me.txtProductID.Location = New System.Drawing.Point(152, 16)
        Me.txtProductID.Name = "txtProductID"
        Me.txtProductID.ReadOnly = True
        Me.txtProductID.TabIndex = 2
        Me.txtProductID.Text = ""
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Location = New System.Drawing.Point(152, 40)
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.ReadOnly = True
        Me.txtUnitPrice.TabIndex = 3
        Me.txtUnitPrice.Text = ""
        '
        'nupQuantity
        '
        Me.nupQuantity.Location = New System.Drawing.Point(152, 72)
        Me.nupQuantity.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.nupQuantity.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nupQuantity.Name = "nupQuantity"
        Me.nupQuantity.Size = New System.Drawing.Size(40, 20)
        Me.nupQuantity.TabIndex = 5
        Me.nupQuantity.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(40, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Quantity:"
        '
        'ctnOK
        '
        Me.ctnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ctnOK.Location = New System.Drawing.Point(48, 112)
        Me.ctnOK.Name = "ctnOK"
        Me.ctnOK.TabIndex = 6
        Me.ctnOK.Text = "OK"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(136, 112)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "Cancel"
        '
        'dlgOrderItem
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 149)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCancel, Me.ctnOK, Me.Label3, Me.nupQuantity, Me.txtUnitPrice, Me.txtProductID, Me.Label2, Me.Label1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "dlgOrderItem"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Order Item"
        CType(Me.nupQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnTestOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim oOrder As New Order()
        oOrder.AddItem(New OrderItem("ACM-10414", 3.79, 2))
        oOrder.AddItem(New OrderItem("ACM-10414", 3.79, 4))
        oOrder.AddItem(New OrderItem("OIC-5000", 1.99, 2))
        oOrder.AddItem(New OrderItem("MMM-6200", 3.9, 2))

        Dim i As Integer
        For i = 0 To oOrder.OrderItems.Count - 1
            MessageBox.Show(oOrder.OrderItems.Item(i).ToString)
        Next

        MessageBox.Show(oOrder.GetOrderTotal.ToString)

        MessageBox.Show(oOrder.PlaceOrder(1).ToString)
    End Sub
End Class
