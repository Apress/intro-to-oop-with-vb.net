Public Class frmOrder
    Inherits System.Windows.Forms.Form
    Private EmployeeID As Integer
    Private dsProdCat As DataSet
    Private oOrder As Order
    Private oOrderItemDlg As New dlgOrderItem()
    Private oLoginDlg As New dlgLogin()
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents sbOSO As System.Windows.Forms.StatusBar
    Friend WithEvents cboProductCategories As System.Windows.Forms.ComboBox
    Friend WithEvents dgProducts As System.Windows.Forms.DataGrid
    Friend WithEvents dgOrder As System.Windows.Forms.DataGrid
    Friend WithEvents btnRemoveItem As System.Windows.Forms.Button
    Friend WithEvents btnPlaceOrder As System.Windows.Forms.Button
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents btnAddItem As System.Windows.Forms.Button
    Friend WithEvents pnlOrder As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.sbOSO = New System.Windows.Forms.StatusBar()
        Me.cboProductCategories = New System.Windows.Forms.ComboBox()
        Me.dgProducts = New System.Windows.Forms.DataGrid()
        Me.pnlOrder = New System.Windows.Forms.Panel()
        Me.btnPlaceOrder = New System.Windows.Forms.Button()
        Me.btnRemoveItem = New System.Windows.Forms.Button()
        Me.dgOrder = New System.Windows.Forms.DataGrid()
        Me.btnAddItem = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.dgProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlOrder.SuspendLayout()
        CType(Me.dgOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'sbOSO
        '
        Me.sbOSO.Location = New System.Drawing.Point(0, 391)
        Me.sbOSO.Name = "sbOSO"
        Me.sbOSO.Size = New System.Drawing.Size(480, 22)
        Me.sbOSO.TabIndex = 0
        Me.sbOSO.Text = "You must login to place an order."
        '
        'cboProductCategories
        '
        Me.cboProductCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProductCategories.Location = New System.Drawing.Point(168, 8)
        Me.cboProductCategories.Name = "cboProductCategories"
        Me.cboProductCategories.Size = New System.Drawing.Size(121, 21)
        Me.cboProductCategories.TabIndex = 1
        '
        'dgProducts
        '
        Me.dgProducts.AllowNavigation = False
        Me.dgProducts.CaptionText = "Products:"
        Me.dgProducts.DataMember = ""
        Me.dgProducts.FlatMode = True
        Me.dgProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgProducts.Location = New System.Drawing.Point(32, 56)
        Me.dgProducts.Name = "dgProducts"
        Me.dgProducts.ReadOnly = True
        Me.dgProducts.Size = New System.Drawing.Size(416, 136)
        Me.dgProducts.TabIndex = 2
        '
        'pnlOrder
        '
        Me.pnlOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlOrder.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnPlaceOrder, Me.btnRemoveItem, Me.dgOrder, Me.btnAddItem})
        Me.pnlOrder.Enabled = False
        Me.pnlOrder.Location = New System.Drawing.Point(16, 200)
        Me.pnlOrder.Name = "pnlOrder"
        Me.pnlOrder.Size = New System.Drawing.Size(456, 176)
        Me.pnlOrder.TabIndex = 3
        '
        'btnPlaceOrder
        '
        Me.btnPlaceOrder.Location = New System.Drawing.Point(240, 142)
        Me.btnPlaceOrder.Name = "btnPlaceOrder"
        Me.btnPlaceOrder.Size = New System.Drawing.Size(80, 24)
        Me.btnPlaceOrder.TabIndex = 2
        Me.btnPlaceOrder.Text = "Place Order"
        '
        'btnRemoveItem
        '
        Me.btnRemoveItem.Location = New System.Drawing.Point(152, 142)
        Me.btnRemoveItem.Name = "btnRemoveItem"
        Me.btnRemoveItem.Size = New System.Drawing.Size(80, 24)
        Me.btnRemoveItem.TabIndex = 1
        Me.btnRemoveItem.Text = "Remove Item"
        '
        'dgOrder
        '
        Me.dgOrder.CaptionText = "OrderItems:"
        Me.dgOrder.DataMember = ""
        Me.dgOrder.FlatMode = True
        Me.dgOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgOrder.Location = New System.Drawing.Point(16, 27)
        Me.dgOrder.Name = "dgOrder"
        Me.dgOrder.Size = New System.Drawing.Size(416, 104)
        Me.dgOrder.TabIndex = 0
        '
        'btnAddItem
        '
        Me.btnAddItem.Location = New System.Drawing.Point(56, 142)
        Me.btnAddItem.Name = "btnAddItem"
        Me.btnAddItem.Size = New System.Drawing.Size(72, 24)
        Me.btnAddItem.TabIndex = 5
        Me.btnAddItem.Text = "Add Item"
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(304, 16)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(88, 24)
        Me.btnLogin.TabIndex = 4
        Me.btnLogin.Text = "Login"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(400, 16)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(64, 24)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(48, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Catagories:"
        '
        'frmOrder
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(480, 413)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.btnExit, Me.btnLogin, Me.pnlOrder, Me.dgProducts, Me.cboProductCategories, Me.sbOSO})
        Me.Name = "frmOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Office Supply Ordering"
        CType(Me.dgProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlOrder.ResumeLayout(False)
        CType(Me.dgOrder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmOrder_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim oProdCat As New ProductCatalog()
        dsProdCat = oProdCat.getProductInfo
        cboProductCategories.DataSource = dsProdCat
        cboProductCategories.DisplayMember = "Category.Name"

        dgProducts.DataSource = dsProdCat
        dgProducts.DataMember = "Category.drCat_Prod"
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim oEmployee As New Employee()
        Dim strUserName As String
        Dim strPassword As String

        If oLoginDlg.ShowDialog(Me) = DialogResult.OK Then
            strUserName = oLoginDlg.txtName.Text
            strPassword = oLoginDlg.txtPassword.Text
            EmployeeID = oEmployee.Login(strUserName, strPassword)
            If EmployeeID > 0 Then
                sbOSO.Text = "You are logged in as employee number " & EmployeeID
                pnlOrder.Enabled = True
                oOrder = New Order()
            Else
                MessageBox.Show("You could not be verified. Please try again.")
                pnlOrder.Enabled = False
            End If
        End If
    End Sub

    Private Sub btnAddItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddItem.Click
        Dim strProdID As String
        Dim dblUnitPrice As Double
        Dim intQuantity As Integer
        Dim intRowIndex As Integer
        intRowIndex = dgProducts.CurrentRowIndex
        strProdID = dgProducts.Item(intRowIndex, 0)
        dblUnitPrice = dgProducts.Item(intRowIndex, 4)

        oOrderItemDlg.txtProductID.Text = strProdID
        oOrderItemDlg.txtUnitPrice.Text = dblUnitPrice.ToString
        If oOrderItemDlg.ShowDialog(Me) = DialogResult.OK Then
            intQuantity = oOrderItemDlg.nupQuantity.Value
            oOrder.AddItem(New OrderItem(strProdID, dblUnitPrice, intQuantity))
            dgOrder.DataSource = Nothing
            dgOrder.DataSource = oOrder.OrderItems
        End If
    End Sub


    Private Sub btnRemoveItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemoveItem.Click
        Dim strProdID As String
        Dim intRowIndex As Integer
        intRowIndex = dgOrder.CurrentRowIndex
        strProdID = dgOrder.Item(intRowIndex, 3)
        oOrder.RemoveItem(strProdID)
        dgOrder.DataSource = Nothing
        dgOrder.DataSource = oOrder.OrderItems
    End Sub

    
    
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        oLoginDlg.Close()
        oOrderItemDlg.Close()
        Me.Close()
    End Sub

    Private Sub btnPlaceOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaceOrder.Click
        Dim intOrderNumber As Integer
        intOrderNumber = oOrder.PlaceOrder(EmployeeID)
        sbOSO.Text = "The order has been placed. The order number is " & intOrderNumber
    End Sub
End Class
