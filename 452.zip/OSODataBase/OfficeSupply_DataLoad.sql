/******************************************************************************
**        File: DataPopulation.sql
**        Name: DataPopulation
**        Desc: Populates the OfficeSupply database.
**
**        Date: 3/19/2002
**
*******************************************************************************/

-- switch to the OfficeSupply database
USE OfficeSupply;

-- insert Employee table data
INSERT INTO Employee VALUES(1, 'dclark','drc','HR',0);
INSERT INTO Employee VALUES(2, 'jsmith','js','IS',1);
INSERT INTO Employee VALUES(3, 'mjones','mj','HR',1);
INSERT INTO Employee VALUES(4, 'klink','kl','IS',0);

-- insert category table data
INSERT INTO category VALUES(1,'Audio Visual','');
INSERT INTO category VALUES(2,'Art Supplies','');
INSERT INTO category VALUES(3,'Cleaning Supplies','');
INSERT INTO category VALUES(4,'Computer Supplies','');
INSERT INTO category VALUES(5,'Desk Accessories','');
INSERT INTO category VALUES(6,'Writing Supplies','');
INSERT INTO category VALUES(7,'Printer Supplies','');


-- insert Supplier table data
INSERT INTO Supplier VALUES (1,'XYZ Office Supplies');
INSERT INTO Supplier VALUES (2,'ABC Office Products');


-- insert Product table data
INSERT INTO Product VALUES ('ACM-10414 ',2,'Ruler','12 inch stainless steel',3.79,2);
INSERT INTO Product VALUES ('APO-CG7070',1,'Transparency','Quick dry ink jet',24.49,1);
INSERT INTO Product VALUES ('APO-FXL   ',1,'Overhead Bulb','High intensity replacement bulb',12.00,1);
INSERT INTO Product VALUES ('APO-MP1200',1,'Laser Pointer','General purpose laser pointer',29.99,2);
INSERT INTO Product VALUES ('BIN-68401 ',2,'Colored Pencils','Non toxic 12 pack',2.84,1);
INSERT INTO Product VALUES ('DRA-91249 ',3,'All-Purpose Cleaner','Use on all washable surfaces',4.29,2);
INSERT INTO Product VALUES ('FOH-28124 ',3,'Paper Hand Towels','320 sheets per roll',5.25,1);
INSERT INTO Product VALUES ('IMN-41143 ',4,'CD-R','700 mb with jewel case',1.09,1);
INSERT INTO Product VALUES ('IMN-44766 ',4,'3.5 inch Disks','High Density Formatted Box of 10',5.99,1);
INSERT INTO Product VALUES ('KMW-12164 ',4,'Monitor wipes','Non abrasive lint free',6.99,2);
INSERT INTO Product VALUES ('KMW-22256 ',4,'Dust Blaster','Ozone safe no CFCs',8.99,2);
INSERT INTO Product VALUES ('MMM-6200  ',2,'Clear Tape','1 inch wide 6 rolls',3.90,1);
INSERT INTO Product VALUES ('MMM-9700P ',1,'Overhead Projector','Portable with travel cover',759.97,1);
INSERT INTO Product VALUES ('OIC-5000  ',2,'Glue Stick','Oderless non toxic',1.99,2);


 