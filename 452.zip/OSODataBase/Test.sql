Use OfficeSupply
go
Select * from product 