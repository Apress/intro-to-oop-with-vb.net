/******************************************************************************
**		File: OfficeSupplydb_Schema.sql
**		Name: Physical Database Schema SQL Script
**		Desc: This script will create the .NET OfficeSupply database schema
**
**		Date: 3/19/2002
**
*******************************************************************************/

USE master;

-- create the database
IF NOT EXISTS (SELECT dbid FROM sysdatabases WHERE name = 'OfficeSupply')
CREATE DATABASE OfficeSupply;
GO

-------------------------------------------------------------------------------
--
-- Database Tables
--
-------------------------------------------------------------------------------

-- switch to the OfficeSupply database
USE OfficeSupply;
GO
-------------------------------------------------------------------------------
-- Employee Table
-------------------------------------------------------------------------------
CREATE TABLE Employee
(
    EmployeeID		int		not null,
    UserName            varchar(20)     NOT NULL,
    [Password]          varchar(25)     NOT NULL,
    Department		Char(2)		Not null,
    Manager		bit		Not Null
);

-- add the primary key constraints
ALTER TABLE Employee ADD
    CONSTRAINT PK_Employee
    PRIMARY KEY CLUSTERED (EmployeeID);

-- grant access
GRANT ALL ON Employee TO PUBLIC;
GO
 
-------------------------------------------------------------------------------
-- Supplier Table
-------------------------------------------------------------------------------
CREATE TABLE Supplier
(
    SuppID              int                    NOT NULL,
    [Name]              varchar(80)            NOT NULL
    );

-- add the primary key constraints
ALTER TABLE Supplier ADD
    CONSTRAINT PK_Supplier
    PRIMARY KEY  CLUSTERED (SuppID);
GO
-- grant access
GRANT ALL ON Supplier TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Orders Table
-------------------------------------------------------------------------------
CREATE TABLE Orders
(
    OrderID             int         IDENTITY   NOT NULL,
    EmployeeID          int                    NOT NULL,
    OrderDate           datetime               NOT NULL,
    Status              char(1)                NOT NULL
);
GO
-- add the primary key constraints
ALTER TABLE Orders ADD
    CONSTRAINT PK_Orders
    PRIMARY KEY  CLUSTERED (OrderID);
-- add the foreign key constraints
ALTER TABLE Orders ADD 
    CONSTRAINT FK_Orders_Employee FOREIGN KEY (EmployeeID)
    REFERENCES Employee (EmployeeID);
    
ALTER TABLE Orders WITH NOCHECK ADD 
	CONSTRAINT DF_Orders_StatusCode DEFAULT ('P') FOR Status
	
ALTER TABLE Orders WITH NOCHECK ADD 
	CONSTRAINT DF_Orders_OrderDate DEFAULT (GETDATE()) FOR OrderDate
GO

-- grant access
GRANT ALL ON Orders TO PUBLIC;
GO



-------------------------------------------------------------------------------
-- Category Table
-------------------------------------------------------------------------------
CREATE TABLE Category
(
    CatID               int               NOT NULL,
    [Name]              varchar(80)            NULL,  
    Descript            varchar(255)           NULL
);

-- add the primary key
ALTER TABLE Category ADD 
    CONSTRAINT PK_Category
    PRIMARY KEY  CLUSTERED (CatID);

-- grant access
GRANT ALL ON Category TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Product Table
-------------------------------------------------------------------------------
CREATE TABLE Product
(
    ProductID           char(10)               NOT NULL,
    CatID               int                    NOT NULL,
    [Name]              varchar(80)            NULL,
    Descript            varchar(255)           NULL,
    UnitCost            decimal(10, 2)         NULL,
    SuppID              int                    NULL
);

-- add the primary key constraints
ALTER TABLE Product ADD 
    CONSTRAINT PK_Product
    PRIMARY KEY  CLUSTERED (ProductID);

-- add the foreign key constraints
ALTER TABLE Product ADD 
    CONSTRAINT FK_Product_Category FOREIGN KEY (CatID)
    REFERENCES category (CatID);
ALTER TABLE Product ADD
    CONSTRAINT FK_Product_Supplier FOREIGN KEY (SuppID)
    REFERENCES Supplier (SuppID);
-- grant access
GRANT ALL ON Product TO PUBLIC;
GO









-------------------------------------------------------------------------------
-- OrderItem Table
-------------------------------------------------------------------------------
CREATE TABLE OrderItem
(
    OrderID             int                    NOT NULL,
    ProductID           char(10)               NOT NULL,
    Quantity            int                    NOT NULL  
);

-- add the primary key constraints
ALTER TABLE OrderItem ADD
    CONSTRAINT PK_OrderItem
    PRIMARY KEY  CLUSTERED (OrderID, ProductID);

-- add the foreign key constraints
ALTER TABLE OrderItem ADD 
    CONSTRAINT FK_OrderItem_Orders FOREIGN KEY (OrderID)
    REFERENCES Orders (OrderID);

ALTER TABLE OrderItem ADD 
    CONSTRAINT FK_OrderItem_Product FOREIGN KEY (ProductID)
    REFERENCES Product (ProductID);

-- grant access
GRANT ALL ON OrderItem TO PUBLIC;
GO








