SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

Use OfficeSupply
go
-------------------------------------------------------------------------------
-- up_PlaceOrder
-------------------------------------------------------------------------------
/******************************************************************************
	Add order to database. Example of using this stored proc is shown below.
	
	declare @xmlOrder varchar(8000)
	set @xmlOrder = 
		'
		<Order EmployeeID="1">
		  <OrderItem ProductID="EST-1" Quantity="4" />
		  <OrderItem ProductID="EST-5" Quantity="2" />
		  <OrderItem ProductID="EST-9" Quantity="6" />
		</Orders>
		'

	exec up_PlaceOrder @xmlOrder
	
*******************************************************************************/
Create  PROCEDURE up_PlaceOrder
(
    @xmlOrder                 varchar(8000)
)
AS

    DECLARE @idoc int		-- xml doc
    DECLARE @OrderID int	-- new order

    -- parse xml doc
    EXEC sp_xml_preparedocument @idoc output, @xmlOrder


    SET NOCOUNT ON
    DECLARE @CurrentError int

    -- start transaction, updating three tables
    BEGIN TRANSACTION

    -- add new order to Orders table
    INSERT INTO Orders (EmployeeID)
    SELECT EmployeeID
    FROM OpenXML(@idoc, '/Order')
    WITH Orders

    -- check for error
    SELECT @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- get new order id
    SELECT @OrderID = @@IDENTITY

    -- add line items to LineItem table
    INSERT INTO OrderItem
    SELECT @OrderID, ProductID, Quantity
    FROM OpenXML(@idoc, '/Order/OrderItem')
    WITH OrderItem

    -- check for error
    SELECT @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    
    -- end of transaction
    COMMIT TRANSACTION

    SET NOCOUNT OFF

    -- done with xml doc
    EXEC sp_xml_removedocument @idoc

    -- return the new order
    RETURN @OrderID

    ERROR_HANDLER:
        ROLLBACK TRANSACTION
        SET NOCOUNT OFF    
        RETURN 0    

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

