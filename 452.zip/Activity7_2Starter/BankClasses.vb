Public Class Account
    Private m_intAccountNumber As Integer
    Protected m_dblBalance As Double
    Public ReadOnly Property Balance() As Double
        Get
            Return m_dblBalance
        End Get
    End Property
    Public Property AccountNumber() As Integer
        Get
            Return m_intAccountNumber
        End Get
        Set(ByVal Value As Integer)
            m_intAccountNumber = Value
        End Set
    End Property

    Public Function GetBalance() As Double
        'Data normally retrieved from database. Hard coded for demo only
        If AccountNumber = 1 Then
            m_dblBalance = 1000
            Return m_dblBalance
        ElseIf m_intAccountNumber = 2 Then
            m_dblBalance = 2000
            Return m_dblBalance
        Else
            Throw New Exception("Account number incorrect.")
        End If
    End Function

    Public Function Withdraw(ByVal dblAmount As Double) As Double

    End Function
End Class
Public Class CheckingAccount
    Inherits Account

End Class

Public Class SavingsAccount
    Inherits Account

End Class

