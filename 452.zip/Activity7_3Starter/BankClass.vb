Imports System.Collections.CollectionBase
Public Class AccountCollection
    Inherits CollectionBase
    Public Sub Add(ByVal value As Account)
        list.Add(value)
    End Sub
End Class
